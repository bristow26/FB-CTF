#!/bin/bash
# lame script 
# i run every 5 minutes
echo lame > /opt/lame.log

